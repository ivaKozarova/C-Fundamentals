﻿using System;

namespace IteratorsAndComparators

{
    public class StartUp
    {
        static void Main(string[] args)
        {
           // var book1 = new Book("nasam", 2020, "GGS");
           //var book2 = new Book("nasam", 2020, " Gosho", "Pesho");
           // var book3 = new Book("Z", 2021);
            //  var book4 = new Book("A", 2021);
            //  var book5 = new Book("asd", 1984);
            //  var book6 = new Book("Imalo", 2012);

            //var library = new Library(book1, book2);
            //library.Add(book3);
            //  library.Books.Sort(new BookComparator());


            //foreach (var book in library)
            //{

            //    Console.WriteLine(book);
            //}


            //foreach (var book in library)
            //{
            //    Console.WriteLine(book);
            //}

            //foreach (var bok in library)
            //{
            //    Console.WriteLine(bok.Year);
            //}

            //var library2 = new Library(book3 , book2 , book1);

            //foreach (var book in library2)
            //{
            //    Console.WriteLine(book.Title);
            //}

        }
    }
}
