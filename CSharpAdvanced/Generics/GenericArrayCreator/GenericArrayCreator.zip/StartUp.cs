﻿using System;

namespace GenericArrayCreator
{
    class StartUp
    {
        static void Main(string[] args)
        {
           var arr=  ArrayCreator.Create(5, "Pesho");
            var num = ArrayCreator.Create(5, 6);
           
        }
    }
}
