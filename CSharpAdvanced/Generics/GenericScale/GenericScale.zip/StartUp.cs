﻿using System;
using System.Data.Common;

namespace GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var scale = new EqualityScale<string>("more", "more");
            Console.WriteLine(scale.AreEqual());

        }
    }
}
