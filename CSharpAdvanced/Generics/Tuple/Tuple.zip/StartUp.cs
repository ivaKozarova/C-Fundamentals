﻿using System;

namespace Tuple
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var inputPersonInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            var name = $"{inputPersonInfo[0]} {inputPersonInfo[1]}";
            var address = inputPersonInfo[2];
            var personInfo = new Tuple<string, string>(name,address);


            var inputPersonBeer = Console.ReadLine().Split();

            var nameBeer = inputPersonBeer[0];
            var beerInLiters = int.Parse(inputPersonBeer[1]);
            var amountOfBeer = new Tuple<string, int>(nameBeer, beerInLiters);

            var inputNumbers = Console.ReadLine().Split();

            var intNum = int.Parse(inputNumbers[0]);
            var doubleNum = double.Parse(inputNumbers[1]);
            var numbers = new Tuple<int, double>(intNum, doubleNum);

            Console.WriteLine(personInfo);
            Console.WriteLine(amountOfBeer);
            Console.WriteLine(numbers);


        }
    }
}
