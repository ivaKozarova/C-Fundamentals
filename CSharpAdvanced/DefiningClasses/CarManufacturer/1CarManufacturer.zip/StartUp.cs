﻿using System;
using System.Dynamic;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //string make = Console.ReadLine();
            //string model = Console.ReadLine();
            //int year = int.Parse(Console.ReadLine());
            //double fuelQuantity = double.Parse(Console.ReadLine());
            //double fuelConsumption = double.Parse(Console.ReadLine());

            //Car firstCar = new Car();
            //Car secondCar = new Car(make, model, year);
            //Car thirdCar = new Car(make, model, year, fuelQuantity, fuelConsumption);
           

            //car.Make = "vw";
            //car.Model = " golf";
            //car.Year = 2020;
            //car.FuelQuantity = 8.5;
            //car.FuelConsumtion = 6;

            //car.Drive(100);
            //Console.WriteLine(car.WhoAmI());


        }
    }
}
