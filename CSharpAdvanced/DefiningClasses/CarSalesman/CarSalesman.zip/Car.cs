﻿using System;
using System.Text;
using System.Threading;

namespace CarSalesman
{
    class Car
    {
        private string model;
        private Engine engine;
        private double? weight;
        private string color;

        public Car(string model, Engine engine)
        {
            this.Model = model;
            this.Engine = engine;
        }
        public Car(string model, Engine engine, double weight)
            :this(model,engine)
        {
            this.Weight = weight;
        }
        public Car(string model , Engine engine, string color)
            :this(model, engine)
        {
            this.Color = color;
        }
        public Car(string model, Engine engine , double weight , string color)
            :this(model, engine)
        {
            this.Weight = weight;
            this.Color = color;
        }

        public string Model
        {
            get { return this.model; }
            set { this.model = value; }
        }

        public Engine Engine
        {
            get { return this.engine; }
            set { this.engine = value; }
        }
        public double? Weight
        {
            get { return this.weight; }
            set { this.weight = value; }
        }
        public string Color
        {
            get { return this.color; }
            set { this.color = value; }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            string stringWeight = this.Weight.HasValue ? 
                    this.Weight.ToString() : "n/a";
            string stringColor = String.IsNullOrEmpty(this.Color) ?
                "n/a" : this.Color;
            sb
                .AppendLine($"{this.Model}:")
                .AppendLine($"  {this.Engine}")
                .AppendLine($"  Weight: {stringWeight}")
                .AppendLine($"  Color: {stringColor}");
           
            return sb.ToString().TrimEnd();
        }
    }
}
